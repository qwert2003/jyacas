package net.sf.yacas;

/// Abstract class which can be put inside a LispGenericClass.
abstract class GenericClass {
    public abstract String TypeName();
}
