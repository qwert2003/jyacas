package net.sf.yacas;


class YacasException extends Exception
{
  public YacasException(String message)
  {
    super(message);
  }
}
