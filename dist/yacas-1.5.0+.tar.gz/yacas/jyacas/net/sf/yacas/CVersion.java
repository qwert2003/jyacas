package net.sf.yacas;

class CVersion {
    static String VERSION = "1.5.0+ (902873b)";
}
