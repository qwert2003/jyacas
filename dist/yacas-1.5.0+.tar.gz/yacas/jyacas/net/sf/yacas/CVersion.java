package net.sf.yacas;

class CVersion {
    static String VERSION = "1.5.0+ (22f4188)";
}
