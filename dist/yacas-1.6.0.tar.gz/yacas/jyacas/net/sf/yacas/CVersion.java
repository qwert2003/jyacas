package net.sf.yacas;

class CVersion {
    static String VERSION = "1.6.0";
}
